import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VerifyPassword {    
    public boolean verify(String password){
        int tam = password.length();
        
        return (tam >= 12 && tam <= 14) && checkString(password);
    }
    
    private boolean checkString(String str) {
        char ch;
        boolean capitalFlag = false;
        boolean lowerCaseFlag = false;
        boolean numberFlag = false;
        boolean repeatFlag = hasRepeatedLetters(str);
        
        Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(str);
        boolean specialFlag = m.find();
        
        if(!specialFlag && repeatFlag)
            return false;        
        
        for(int i=0;i < str.length();i++) {
            ch = str.charAt(i);
            if( Character.isDigit(ch)) {
                numberFlag = true;
            }
            else if (Character.isUpperCase(ch)) {
                capitalFlag = true;
            } else if (Character.isLowerCase(ch)) {
                lowerCaseFlag = true;
            }
            if(numberFlag && capitalFlag && lowerCaseFlag)
                return true;
        }
        return false;
    }
    
    private boolean hasRepeatedLetters(String str) {
        Matcher m = Pattern.compile("(.+)\\1+").matcher(str);
        return m.find();
    }
}
