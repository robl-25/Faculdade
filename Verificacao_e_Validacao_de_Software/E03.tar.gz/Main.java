public class Main{
  public static void main(String[] args){
    VerifyPassword v = new VerifyPassword();
    String senha = "asdFghjkl12#";
    boolean is_security = v.verify(senha);
    System.out.println("Senha: " + senha);
    
    if(is_security){
        System.out.println("É segura");
    }
    else{
        System.out.println("Não é segura");
    }
    
    
    senha = "asdFgjkl12#";
    is_security = v.verify(senha);
    System.out.println("Senha: " + senha);
    
    if(is_security){
        System.out.println("É segura");
    }
    else{
        System.out.println("Não é segura");
    }
  }
}
